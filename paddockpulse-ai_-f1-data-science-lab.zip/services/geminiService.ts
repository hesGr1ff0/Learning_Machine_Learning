
import { GoogleGenAI, Type } from "@google/genai";
import { AnalysisState, MLResult } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const analyzeF1Data = async (state: AnalysisState): Promise<MLResult> => {
  const prompt = `
    Act as a Senior F1 Data Scientist and ML Engineer using the FastF1 Python library.
    The user is performing a "tinker" analysis on the following scenario:
    - Season: ${state.season}
    - Grand Prix: ${state.grandPrix}
    - Driver 1: ${state.driver1}
    - Driver 2: ${state.driver2}
    - Session: ${state.sessionType}
    - Python Code Intent:
    \`\`\`python
    ${state.pythonCode}
    \`\`\`

    TASK:
    1. Simulate the execution of this FastF1 analysis using your internal knowledge of 2023-2024 F1 data.
    2. Provide a detailed machine learning oriented conclusion.
    3. Generate high-fidelity visualization data suitable for a chart (JSON format).
    4. If the hypothesis involves driver comparison, focus on delta times and telemetry differences.

    Include a hypothesis summary and a data-backed conclusion.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-pro-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      thinkingConfig: { thinkingBudget: 4000 },
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          hypothesis: { type: Type.STRING },
          conclusion: { type: Type.STRING },
          confidence: { type: Type.NUMBER },
          metrics: {
            type: Type.OBJECT,
            properties: {
              accuracy: { type: Type.NUMBER },
              correlation: { type: Type.NUMBER },
              featureImportance: { type: Type.OBJECT, additionalProperties: { type: Type.NUMBER } }
            }
          },
          visualizationType: { type: Type.STRING, enum: ['line', 'bar', 'scatter'] },
          visualizationData: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                label: { type: Type.STRING },
                value1: { type: Type.NUMBER },
                value2: { type: Type.NUMBER },
                x: { type: Type.NUMBER },
                y: { type: Type.NUMBER }
              }
            }
          }
        },
        required: ["hypothesis", "conclusion", "confidence", "visualizationData", "visualizationType"]
      }
    }
  });

  return JSON.parse(response.text);
};

export const generatePythonSnippet = async (intent: string): Promise<string> => {
  const prompt = `Generate a Python code snippet using the FastF1 and Pandas/Scikit-learn libraries for the following F1 data analysis task: ${intent}. Only return the code, no markdown wrappers if possible, but stay within the logic of a professional data scientist.`;
  
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
  });
  
  return response.text.replace(/```python|```/g, '').trim();
};
