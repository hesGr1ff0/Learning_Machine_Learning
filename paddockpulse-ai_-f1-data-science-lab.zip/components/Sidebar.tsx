
import React from 'react';
import { AnalysisState } from '../types';

interface SidebarProps {
  state: AnalysisState;
  setState: React.Dispatch<React.SetStateAction<AnalysisState>>;
}

const Sidebar: React.FC<SidebarProps> = ({ state, setState }) => {
  const handleChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const { name, value } = e.target;
    setState(prev => ({ ...prev, [name]: value }));
  };

  const drivers = ["VER", "PER", "HAM", "RUS", "LEC", "SAI", "NOR", "PIA", "ALO", "STR", "GAS", "OCO", "ALB", "SAR", "TSU", "RIC", "BOT", "ZHO", "HUL", "MAG"];
  const gps = ["Bahrain", "Saudi Arabia", "Australia", "Japan", "China", "Miami", "Monaco", "Canada", "Spain", "Austria", "Great Britain", "Hungary", "Belgium", "Netherlands", "Italy", "Azerbaijan", "Singapore", "USA", "Mexico", "Brazil", "Las Vegas", "Qatar", "Abu Dhabi"];

  return (
    <aside className="w-80 h-full bg-[#111114] border-r border-white/10 p-6 flex flex-col gap-6 overflow-y-auto">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 f1-gradient rounded-lg flex items-center justify-center font-bold text-white italic">F1</div>
        <div>
          <h1 className="font-bold text-lg leading-tight">PaddockPulse</h1>
          <p className="text-xs text-zinc-500 uppercase tracking-widest">ML DATA LAB</p>
        </div>
      </div>

      <nav className="space-y-4">
        <div>
          <label className="text-xs font-semibold text-zinc-400 uppercase mb-2 block">Season</label>
          <select 
            name="season" 
            value={state.season} 
            onChange={handleChange}
            className="w-full bg-zinc-900 border border-white/10 rounded-md p-2 text-sm focus:border-red-500 outline-none transition-colors"
          >
            <option>2024</option>
            <option>2023</option>
          </select>
        </div>

        <div>
          <label className="text-xs font-semibold text-zinc-400 uppercase mb-2 block">Grand Prix</label>
          <select 
            name="grandPrix" 
            value={state.grandPrix} 
            onChange={handleChange}
            className="w-full bg-zinc-900 border border-white/10 rounded-md p-2 text-sm focus:border-red-500 outline-none transition-colors"
          >
            {gps.map(gp => <option key={gp} value={gp}>{gp}</option>)}
          </select>
        </div>

        <div>
          <label className="text-xs font-semibold text-zinc-400 uppercase mb-2 block">Session</label>
          <select 
            name="sessionType" 
            value={state.sessionType} 
            onChange={handleChange}
            className="w-full bg-zinc-900 border border-white/10 rounded-md p-2 text-sm focus:border-red-500 outline-none transition-colors"
          >
            <option value="R">Race</option>
            <option value="Q">Qualifying</option>
            <option value="FP3">Practice 3</option>
          </select>
        </div>

        <div className="pt-4 border-t border-white/5">
          <label className="text-xs font-semibold text-zinc-400 uppercase mb-2 block">Comparison</label>
          <div className="grid grid-cols-2 gap-2">
            <select 
              name="driver1" 
              value={state.driver1} 
              onChange={handleChange}
              className="w-full bg-zinc-900 border border-white/10 rounded-md p-2 text-sm"
            >
              {drivers.map(d => <option key={d} value={d}>{d}</option>)}
            </select>
            <select 
              name="driver2" 
              value={state.driver2} 
              onChange={handleChange}
              className="w-full bg-zinc-900 border border-white/10 rounded-md p-2 text-sm"
            >
              {drivers.map(d => <option key={d} value={d}>{d}</option>)}
            </select>
          </div>
        </div>
      </nav>

      <div className="mt-auto p-4 bg-zinc-900/50 rounded-xl border border-white/5">
        <h3 className="text-xs font-bold text-red-500 uppercase mb-1">Status</h3>
        <p className="text-xs text-zinc-400">Connected to FastF1 Virtual Kernel</p>
      </div>
    </aside>
  );
};

export default Sidebar;
