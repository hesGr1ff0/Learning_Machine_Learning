
import React from 'react';
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  BarChart, Bar, ScatterChart, Scatter, Cell, Legend
} from 'recharts';
import { MLResult } from '../types';

interface VisualizationPanelProps {
  result: MLResult | null;
  loading: boolean;
  driver1: string;
  driver2: string;
}

const VisualizationPanel: React.FC<VisualizationPanelProps> = ({ result, loading, driver1, driver2 }) => {
  if (loading) {
    return (
      <div className="h-full flex flex-col items-center justify-center bg-zinc-900/30 rounded-xl border border-dashed border-white/10 animate-pulse">
        <div className="w-12 h-12 border-4 border-red-500 border-t-transparent rounded-full animate-spin mb-4"></div>
        <p className="text-sm text-zinc-500">Processing telemetry frames...</p>
      </div>
    );
  }

  if (!result) {
    return (
      <div className="h-full flex flex-col items-center justify-center bg-zinc-900/30 rounded-xl border border-dashed border-white/10 text-center p-8">
        <div className="text-4xl mb-4 opacity-20">📊</div>
        <h3 className="text-zinc-400 font-semibold mb-2">No Data Visualized</h3>
        <p className="text-sm text-zinc-600 max-w-xs">Run an execution to generate telemetry deltas and ML feature analysis.</p>
      </div>
    );
  }

  const renderChart = () => {
    switch (result.visualizationType) {
      case 'bar':
        return (
          <BarChart data={result.visualizationData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
            <XAxis dataKey="label" stroke="#71717a" fontSize={10} tickLine={false} axisLine={false} />
            <YAxis stroke="#71717a" fontSize={10} tickLine={false} axisLine={false} />
            <Tooltip 
              contentStyle={{ backgroundColor: '#18181b', border: '1px solid #3f3f46', borderRadius: '8px' }}
              itemStyle={{ color: '#e2e8f0' }}
            />
            <Bar dataKey="value1" name={driver1} fill="#ef4444" radius={[4, 4, 0, 0]} />
            <Bar dataKey="value2" name={driver2} fill="#3b82f6" radius={[4, 4, 0, 0]} />
          </BarChart>
        );
      case 'scatter':
        return (
          <ScatterChart>
            <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
            <XAxis type="number" dataKey="x" name="Metric X" stroke="#71717a" fontSize={10} />
            <YAxis type="number" dataKey="y" name="Metric Y" stroke="#71717a" fontSize={10} />
            <Tooltip cursor={{ strokeDasharray: '3 3' }} />
            <Scatter name={driver1} data={result.visualizationData} fill="#ef4444" />
          </ScatterChart>
        );
      default:
        return (
          <LineChart data={result.visualizationData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
            <XAxis dataKey="label" stroke="#71717a" fontSize={10} tickLine={false} axisLine={false} />
            <YAxis stroke="#71717a" fontSize={10} tickLine={false} axisLine={false} />
            <Tooltip 
              contentStyle={{ backgroundColor: '#18181b', border: '1px solid #3f3f46', borderRadius: '8px' }}
            />
            <Legend />
            <Line type="monotone" dataKey="value1" name={driver1} stroke="#ef4444" strokeWidth={2} dot={false} />
            <Line type="monotone" dataKey="value2" name={driver2} stroke="#3b82f6" strokeWidth={2} dot={false} />
          </LineChart>
        );
    }
  };

  return (
    <div className="h-full flex flex-col bg-[#111114] border border-white/10 rounded-xl overflow-hidden">
      <div className="p-4 border-b border-white/5 flex items-center justify-between">
        <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-widest flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
          Live Visualization
        </h3>
        <div className="flex gap-4 text-[10px] uppercase font-bold tracking-tighter">
          <div className="flex items-center gap-1"><span className="w-2 h-2 bg-red-500 rounded-sm"></span> {driver1}</div>
          <div className="flex items-center gap-1"><span className="w-2 h-2 bg-blue-500 rounded-sm"></span> {driver2}</div>
        </div>
      </div>
      <div className="flex-1 p-6">
        <ResponsiveContainer width="100%" height="100%">
          {renderChart()}
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default VisualizationPanel;
