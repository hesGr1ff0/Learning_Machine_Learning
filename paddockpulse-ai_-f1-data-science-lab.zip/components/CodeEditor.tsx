
import React from 'react';

interface CodeEditorProps {
  code: string;
  setCode: (code: string) => void;
  onGenerate: () => void;
}

const CodeEditor: React.FC<CodeEditorProps> = ({ code, setCode, onGenerate }) => {
  return (
    <div className="bg-[#111114] border border-white/10 rounded-xl overflow-hidden flex flex-col h-full">
      <div className="bg-zinc-900/80 px-4 py-2 flex items-center justify-between border-b border-white/5">
        <div className="flex gap-2">
          <div className="w-3 h-3 rounded-full bg-red-500/30"></div>
          <div className="w-3 h-3 rounded-full bg-amber-500/30"></div>
          <div className="w-3 h-3 rounded-full bg-green-500/30"></div>
        </div>
        <span className="text-[10px] text-zinc-500 font-mono tracking-widest uppercase">analysis_kernel.py</span>
      </div>
      <div className="flex-1 relative font-mono text-sm">
        <textarea
          value={code}
          onChange={(e) => setCode(e.target.value)}
          spellCheck={false}
          className="absolute inset-0 w-full h-full bg-transparent p-6 outline-none resize-none text-red-400 placeholder:text-zinc-700 leading-relaxed"
          placeholder="# Use FastF1 to explore a hypothesis...
import fastf1 as ff1
import pandas as pd
from sklearn.ensemble import RandomForestRegressor

session = ff1.get_session(2024, 'Monaco', 'Q')
session.load()"
        />
      </div>
      <div className="p-4 bg-zinc-900/50 border-t border-white/5 flex justify-end gap-3">
        <button 
          onClick={() => onGenerate()}
          className="text-xs text-zinc-400 hover:text-white transition-colors uppercase font-bold px-3 py-1.5"
        >
          Auto-complete
        </button>
        <button 
          onClick={() => {}} 
          className="bg-red-600 hover:bg-red-500 text-white text-xs font-bold px-6 py-2 rounded-lg transition-all active:scale-95 shadow-lg shadow-red-900/20 uppercase tracking-wider"
        >
          Execute Analysis
        </button>
      </div>
    </div>
  );
};

export default CodeEditor;
