
import React from 'react';
import { MLResult } from '../types';

interface InsightCardProps {
  result: MLResult | null;
}

const InsightCard: React.FC<InsightCardProps> = ({ result }) => {
  if (!result) return null;

  return (
    <div className="bg-[#111114] border border-white/10 rounded-xl p-6 space-y-4">
      <div className="flex items-start justify-between">
        <div>
          <h2 className="text-lg font-bold text-white mb-1">Conclusion Matrix</h2>
          <p className="text-xs text-zinc-500 uppercase tracking-widest">ML Interpretation Engine</p>
        </div>
        <div className="text-right">
          <div className="text-2xl font-black text-red-500 italic">{(result.confidence * 100).toFixed(0)}%</div>
          <div className="text-[10px] text-zinc-500 uppercase">Confidence Score</div>
        </div>
      </div>

      <div className="p-4 bg-zinc-900/50 rounded-lg border-l-4 border-red-500">
        <h4 className="text-xs font-bold text-zinc-300 uppercase mb-2">Validated Hypothesis</h4>
        <p className="text-sm text-zinc-400 leading-relaxed italic">"{result.hypothesis}"</p>
      </div>

      <div className="space-y-2">
        <h4 className="text-xs font-bold text-zinc-300 uppercase">Key Insights</h4>
        <p className="text-sm text-zinc-400 leading-relaxed">
          {result.conclusion}
        </p>
      </div>

      {result.metrics.featureImportance && (
        <div className="pt-4 border-t border-white/5">
          <h4 className="text-xs font-bold text-zinc-300 uppercase mb-3">Model Feature Importance</h4>
          <div className="space-y-3">
            {Object.entries(result.metrics.featureImportance).map(([feature, weight]) => (
              <div key={feature} className="space-y-1">
                <div className="flex justify-between text-[10px] uppercase font-semibold text-zinc-500">
                  <span>{feature}</span>
                  <span>{(weight * 100).toFixed(1)}%</span>
                </div>
                <div className="w-full h-1 bg-zinc-800 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-red-500/80" 
                    style={{ width: `${weight * 100}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default InsightCard;
